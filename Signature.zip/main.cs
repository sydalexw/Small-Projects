using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine("Hello World!");
    Signature();
  }

  public static void Signature(){
    Console.WriteLine("");

    Console.WriteLine("");

    Console.WriteLine("");

    Console.WriteLine("  .-')                _ .-') _       .-') _   ('-.              ");

    Console.WriteLine(" ( OO ).             ( (  OO) )     ( OO ) )_(  OO)             ");

    Console.WriteLine("(_)---\\_)  ,--.   ,--.\\     .'_ ,--./ ,--,'(,------. ,--.   ,--.");

    Console.WriteLine("/    _ |    \\  `.'  / ,`'--..._)|   \\ |  |\\ |  .---'  \\  `.'  / ");

    Console.WriteLine("\\  :` `.  .-')     /  |  |  \\  '|    \\|  | )|  |    .-')     /  ");

    Console.WriteLine(" '..`''.)(OO  \\   /   |  |   ' ||  .     |/(|  '--.(OO  \\   /   ");

    Console.WriteLine(".-._)   \\ |   /  /\\_  |  |   / :|  |\\    |  |  .--' |   /  /\\_  ");

    Console.WriteLine("\\       / `-./  /.__) |  '--'  /|  | \\   |  |  `---.`-./  /.__) ");

    Console.WriteLine(" `-----'    `--'      `-------' `--'  `--'  `------'  `--'      ");

    Console.WriteLine("");

    Console.WriteLine("");

    Console.WriteLine("");

    Console.WriteLine("Thanks for using my program");


  }
}